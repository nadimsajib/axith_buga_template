/**
 * Created by nadim on 1/10/16.
 */
window.onload = function myFunction() {
    var li = document.getElementById('pv1');
    if ( $('#pv1 li').hasClass('active') ){
        li.style.display = 'block';
    }else{
        li.style.display = 'none';
    }

    var li2 = document.getElementById('pv2');
    if ( $('#pv2 li').hasClass('active') ){
        li2.style.display = 'block';
    }else{
        li2.style.display = 'none';
    }
    //alert(id);
}

function toggle_visibility(id) {
    var e = document.getElementById(id);
    if (e.style.display == 'block' || e.style.display==''){
        e.style.display = 'none';
    }else{
        e.style.display = 'block';
    }
}