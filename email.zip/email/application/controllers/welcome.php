<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct()
       {
            parent::__construct();
            session_start();
            date_default_timezone_set('Asia/Dhaka');
        }
	public function is_logged_in()
	{
		if(isset($_SESSION['buzz_user_id'])){
			return true;
		}
	}
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function login_check()
	{
		if($_POST['password'] != NULL && $_POST['password'] != 0)
		{
			//session_start();
			$email = $this->input->post('email');
			$password = $this->input->post('password');
			//var_dump($this->email_model->explicit('SELECT * FROM user where email = $email AND password= $password'));
			//var_dump($this->email_model->explicit("SELECT * FROM user where email = '".$email."' AND password= '".$password."'"));
			if ($this->email_model->get_entries($email, $password) != null)
			{
				$data = $this->email_model->get_entries($email, $password);
				foreach ($data as $key) {
					$_SESSION['buzz_user_id'] = $key->id;
					$_SESSION['buzz_user_email'] = $key->email;
					$_SESSION['buzz_user_username'] = $key->user_name;
				}
				$_SESSION['email-add'] = $email;
				redirect('welcome/home');
			}
			else {
			$_SESSION['error-login'] = "yes";
			//$this->load->view('welcome_message',$data);
			//$this->load->view('welcome_message');
			redirect('welcome/welcome_message');
			}
		}
		else {
		$_SESSION['error-login'] = "yes";
		//$this->load->view('welcome_message',$data);
		//$this->load->view('welcome_message');
		redirect('welcome/welcome_message');
		}
	}
	public function register()
	{
		$email = $this->input->post('email');
		if ($this->email_model->get_entries_reg($email) == null){
		$data = array(
               'user_name'=>$this->input->post('user_name'),
               'email' =>$this->input->post('email'),
				'password'=>$this->input->post('password'),
				);
		     if($this->db->insert('user', $data))
		     {
		     	$_SESSION['successfully_registar'] ="successfully register please login";
		     	redirect('welcome/index');
		     }
		 }
		 else{
		 	$_SESSION['successfully_registar'] ="Already registered please login";
		    redirect('welcome/index');
		 }
	}
	public function welcome_message(){
		/*$inbox = imap_open('nhaqueriver@gmail.com','riverview','riverview',NULL,1) or die('Cannot connect to Gmail: ' . print_r(imap_errors()));*/
		$this->load->view('welcome_message');
	}
	public function sent_single_email()
	{
		$group_email_id = $this->input->post('group_email');
		if($group_email_id){
			$subject = $this->input->post('to_subject');
			$message = $this->input->post('email_des');
			foreach($group_email_id as $id){
				$this->db->where('group_id',$id);
				$query2 = $this->db->get('group_member')->result_array();
				foreach($query2 as $value){
					$member_name = $value['member_name'];
					$message = $this->input->post('email_des');
					$message1 = "<html>
				<head>
				  <title></title>
				</head>
				<body>
				<p> ".$message." </p>
				</body>
				</html>";
					$headers  = 'MIME-Version: 1.0' . "\r\n";
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

					// Additional headers
					$headers .= 'From:'.$_SESSION['buzz_user_username'].' <'.$_SESSION['email-add'] .'>' . "\r\n";
					$headers .= "Reply-To: " . $_SESSION["email-add"] . "\r\n";
					$date = date('Y/m/d H:i:s');
					mail($member_name, $subject, $message1, $headers);
						$data = array(
							'des'=>$message,
							'user_id' => $_SESSION['buzz_user_id'],
							'to_email'=>$member_name,
							'subject'=>$subject,
							'user_name'=>$_SESSION['buzz_user_email'],
							'date'=>$date
						);
						$this->db->insert('email', $data);
					$data2 = array(
						'des'=>$message,
						'user_id' => $_SESSION['buzz_user_id'],
						'group_id' => $id,
						'subject'=>$subject,
						'user_name'=>$_SESSION['buzz_user_email'],
						'date'=>$date
					);
					$this->db->insert('group_email', $data2);
					$_SESSION['success_single_email'] = 'successfully sent group email';
					redirect('welcome/home');
				}
			}

		}
		$to = $this->input->post('to_email');
		if($to){
			foreach($to as $value){
				$subject = $this->input->post('to_subject');
				$message = $this->input->post('email_des');
				$message1 = "<html>
				<head>
				  <title></title>
				</head>
				<body>
				<p> ".$message." </p>
				</body>
				</html>";
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

				// Additional headers
				$headers .= 'From:'.$_SESSION['buzz_user_username'].' <'.$_SESSION['email-add'] .'>' . "\r\n";
				$headers .= "Reply-To: " . $_SESSION["email-add"] . "\r\n";
				$date = date('Y/m/d H:i:s');
				mail($value, $subject, $message1, $headers);
				$data = array(
					'des'=>$message,
					'user_id' => $_SESSION['buzz_user_id'],
					'to_email'=>$value,
					'subject'=>$subject,
					'user_name'=>$_SESSION['buzz_user_email'],
					'date'=>$date
				);
				$this->db->insert('email', $data);
				$_SESSION['success_single_email'] = 'successfully sent to '.$value.'';
				redirect('welcome/home');
			}

		}
		//session_start();
		$to      = $this->input->post('to_email');
		$subject = $this->input->post('to_subject');
		$message = $this->input->post('email_des');
		$message1 = "<html>
				<head>
				  <title></title>
				</head>
				<body>
				<p> ".$message." </p>
				</body>
				</html>";
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

				// Additional headers
				$headers .= 'From:'.$_SESSION['buzz_user_username'].' <'.$_SESSION['email-add'] .'>' . "\r\n";
				$headers .= "Reply-To: " . $_SESSION["email-add"] . "\r\n";
		$date = date('Y/m/d H:i:s');
		mail($to, $subject, $message1, $headers);
		$data = array(
               'des'=>$message,
               'user_id' => $_SESSION['buzz_user_id'], 
				'to_email'=>$to,
				'subject'=>$subject,
				'user_name'=>$_SESSION['buzz_user_email'],
				'date'=>$date
				);
		$this->db->insert('email', $data);
		$_SESSION['success_single_email'] = 'successfully sent to '.$to.'';
		redirect('welcome/home');
		//$this->load->view('home',$data);
	}
	public function manage_group()
	{
		$user_id = $_SESSION['buzz_user_id'];
		$user_email = $_SESSION['buzz_user_email'];
		$this->db->group_by('user_id');
		$query = $this->db->get_where('group_member', array('member_name' => $user_email));
			$data['group_info_user'] = $query->result();
			$a=0;
			foreach ($data['group_info_user'] as $value) {
			$group_id_for = $value->group_id;
			$this->db->where('group_id',$group_id_for);
			$this->db->where('user_id !=',$user_id);
			$query2 = $this->db->get('group_detail');
			$group_name_in_user[$a] = $query2->result();
			$a++;
			}
			if(isset($group_name_in_user)){
			$data['group_name_in_user'] = $group_name_in_user;
		}else { $data['group_name_in_user'] =null; } 
		if($this->db->get_where('group_detail', array('user_id' => $user_id))){
			$this->db->order_by('group_id','desc');
			$query = $this->db->get_where('group_detail', array('user_id' => $user_id));
			$data['group_information'] = $query->result();
			$this->load->view('manage_group',$data);
		}
		else{
		$this->load->view('manage_group');
	}
	}
	public function manage_group_manage()
	{
		$user_id = $_SESSION['buzz_user_id'];
		$user_email = $_SESSION['buzz_user_email'];
		$this->db->group_by('user_id');
		$query = $this->db->get_where('group_member', array('member_name' => $user_email));
			$data['group_info_user'] = $query->result();
			$a=0;
			foreach ($data['group_info_user'] as $value) {
			$group_id_for = $value->group_id;
			$this->db->where('group_id',$group_id_for);
			$this->db->where('user_id !=',$user_id);
			$query2 = $this->db->get('group_detail');
			$group_name_in_user[$a] = $query2->result();
			$a++;
			}
			if(isset($group_name_in_user)){
			$data['group_name_in_user'] = $group_name_in_user;
		}else { $data['group_name_in_user'] =null; } 
		if($this->db->get_where('group_detail', array('user_id' => $user_id))){
			$this->db->order_by('group_id','desc');
			$query = $this->db->get_where('group_detail', array('user_id' => $user_id));
			$data['group_information'] = $query->result();
			$this->load->view('manage_group',$data);
		}
		else{
		$this->load->view('manage_group');
	}
	}
	public function manage_group_create()
	{
		$_SESSION['manage_group_create'] = 1;
		$user_id = $_SESSION['buzz_user_id'];
		$user_email = $_SESSION['buzz_user_email'];
		$this->db->group_by('user_id');
		$query = $this->db->get_where('group_member', array('member_name' => $user_email));
			$data['group_info_user'] = $query->result();
			$a=0;
			foreach ($data['group_info_user'] as $value) {
			$group_id_for = $value->group_id;
			$this->db->where('group_id',$group_id_for);
			$this->db->where('user_id !=',$user_id);
			$query2 = $this->db->get('group_detail');
			$group_name_in_user[$a] = $query2->result();
			$a++;
			}
			if(isset($group_name_in_user)){
			$data['group_name_in_user'] = $group_name_in_user;
		}else { $data['group_name_in_user'] =null; } 
		if($this->db->get_where('group_detail', array('user_id' => $user_id))){
			$this->db->order_by('group_id','desc');
			$query = $this->db->get_where('group_detail', array('user_id' => $user_id));
			$data['group_information'] = $query->result();
			$this->load->view('manage_group',$data);
		}
		else{
		$this->load->view('manage_group');
	}
	}
	public function home()
	{
		$data['user'] = $this->db->get('user')->result_array();
		$data['group'] = $this->db->get('group_detail')->result_array();
		$this->load->view('home',$data);
	}
	public function add_group()
	{
		//var_dump($_POST);
		$email = $_SESSION['buzz_user_email'];
		//session_start();
		$member_no = $this->input->post('member');
		//var_dump($_POST['member_name']);
		$data1 =array(
		'group_name' => $this->input->post('group_name'),
		'user_id' => $_SESSION['buzz_user_id']
		);
		if(
		$this->db->insert('group_detail', $data1)
		){ 
			$group_id = $this->db->insert_id(); }
		    foreach($_POST['group_member'] as $member_name)
			{
				$data2 = array(
               'user_id'=>$_SESSION['buzz_user_id'],
               'group_id' => $group_id, 
				'member_name'=>$member_name
				);
				$this->db->insert('group_member', $data2);
				if($this->email_model->get_entries_email($member_name) == null){
				$to = $member_name;
				$subject ="email buzz system";
				$message = "<html>
				<head>
				  <title>Test Mail</title>
				</head>
				<body>
				<p>Your are added in email buzz system by ".$email." please register here to send group message </p>
					<p><a href='http://nhsoftbd.com/axith/email-buzz/email/index.php/welcome/manage_group' >Click Here for register</a></p>
				</body>
				</html>";
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

				// Additional headers
				$headers .= 'From: Email buzz system <email_buzz@example.com>' . "\r\n";
				$date = date('Y/m/d H:i:s');
				mail($to, $subject, $message, $headers);					
					}
					
		     //$this->db->insert('group_member', $data2);
			}
       	$_SESSION['successfully_insert_gropup_member'] = 'Sucessfully Add group';
        redirect('welcome/manage_group');
	}
	public function add_group_member()
	{
		$group_id = $this->input->post('group_id');	
		$member_name = $this->input->post('member_name');
		$data2 = array(
               'user_id'=>$_SESSION['buzz_user_id'],
               'group_id' => $group_id,
               'member_name'=> $member_name
				);
				$this->db->insert('group_member', $data2);
        redirect('welcome/group_email/'.$group_id);
	}
	public function sent()
	{
		$user_id = $_SESSION['buzz_user_id'];
		$user_email = $_SESSION['buzz_user_email'];
		$this->db->order_by('date','desc');
		$query = $this->db->get_where('email', array('user_id' => $user_id));
		$data['email_inbox'] = $query->result();
		$this->load->view('inbox',$data);
	}
	public function inbox()
	{
		$user_id = $_SESSION['buzz_user_id'];
		$user_email = $_SESSION['buzz_user_email'];
		$this->db->order_by('date','desc');
		$query = $this->db->get_where('email', array('to_email' => $user_email));
		$data['email_inbox'] = $query->result();
		$this->load->view('inbox',$data);
	}
	public function group_email_inbox()
	{
		$user_id = $_SESSION['buzz_user_id'];
		$this->db->order_by('date','desc');
		//$this->db->where('user_id',$user_id);
		//$this->db->or_where('');
		$query = $this->db->get_where('group_email', array('user_id' => $user_id));
		$data['group_email_inbox'] = $query->result();
		$a=0;
		foreach ($data['group_email_inbox'] as $value) {
			$group_id_for = $value->group_id;
			$query2 = $this->db->get_where('group_detail', array('group_id' => $group_id_for));
			$group_name[$a] = $query2->result();
			$a++;
		}
		if(isset($group_name)){
		for($c=0;$c < sizeof($group_name); $c++){
			foreach ($group_name[$c] as $value) {
				$group_name_a[$c] = $value->group_name;
			}			
		}if(isset($group_name_a)!=null || isset($group_name_a)!=0){
		$data['group_name'] = $group_name_a;
		}}
		$this->load->view('inbox',$data);
	}
	public function group_email_inbox_you()
	{
		$user_email = $_SESSION['buzz_user_email'];
		$user_id = $_SESSION['buzz_user_id'];
		$this->db->group_by('group_id');
		$this->db->where('member_name',$user_email);
		$this->db->or_where('user_id',$user_id);
		$query = $this->db->get('group_member');
		//$data['group_member'] = $this->email_model->explicit("select * from group_member where member_name='".$user_email."' or user_id!=".$user_id." group by group_id");
		$data['group_member'] = $query->result_array();
		$a = 0;
		foreach ($data['group_member'] as $value) {
			$group_id = $value['group_id'];
			//$query2 = $this->db->get_where('group_email', array('group_id' => $group_id));
			$group_email_gain[$a] = $this->email_model->explicit("select * from group_email where group_id=".$group_id." and user_name!='".$user_email."' ");
			$a++;
		}
		//var_dump($group_email_gain);
		for ($b=0; $b <sizeof($group_email_gain) ; $b++) {
		foreach ($group_email_gain[$b] as $value) {
			$group_id = $value['group_id'];
			$group_name[$b] = $this->email_model->explicit("select * from group_detail where group_id=".$group_id." ");
		}
		}
		$data['group_email_gain'] = $group_email_gain;
		$data['group_name'] = isset($group_name);
		//$data1 = extract($data['group_name']);
		//var_dump($data);
		$this->load->view('inbox',$data);
	}
	public function delete_email($email_id)
	{
		$this->db->where('email_id', $email_id);
     	$this->db->delete('email');
     	redirect('welcome/inbox');
	}
	public function delete_group_email($email_id)
	{
		$this->db->where('group_email_id', $email_id);
     	$this->db->delete('group_email');
     	redirect('welcome/group_email_inbox');
	}
	public function delete_group($group_id)
	{
		$this->db->where('group_id', $group_id);
     	$this->db->delete('group_detail');
     	$this->db->where('group_id', $group_id);
     	$this->db->delete('group_member');
		$this->db->where('group_id', $group_id);
		$this->db->delete('group_email');
     	redirect('welcome/manage_group');
	}
	public function delete_group_member($member_id,$group_id)
	{
		$this->db->where('member_id', $member_id);
     	$this->db->delete('group_member');
     	redirect('welcome/group_email_edit/'.$group_id);
	}
	public function group_email($group_id)
	{
     	$data['group_id'] = $group_id;
     	$query = $this->db->get_where('group_member', array('group_id' => $group_id));
     	$data['group_member'] = $query->result();
     	$query2 = $this->db->get_where('group_detail', array('group_id' => $group_id));
     	$data['group_information'] = $query2->result();
     	$this->load->view('group_email',$data);
	}
	public function group_email_edit($group_id)
	{
     	$data['group_id'] = $group_id;
     	$query = $this->db->get_where('group_member', array('group_id' => $group_id));
     	$data['group_member'] = $query->result();
     	$query2 = $this->db->get_where('group_detail', array('group_id' => $group_id));
     	$data['group_information'] = $query2->result();
     	$this->load->view('group_email',$data);
	}
	public function sent_group_email()
	{
		$message = $this->input->post('email_des');
		$group_id = $this->input->post('group_id');
		$subject = $this->input->post('to_subject');
		$query = $this->db->get_where('group_member', array('group_id' => $group_id));
		$group_member = $query->result();
		foreach ($group_member as $value) {
			$to = $value->member_name;
			$message1 = "<html>
				<head>
				  <title></title>
				</head>
				<body>
				<p> ".$message." </p>
				</body>
				</html>";
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

				// Additional headers
				$headers .= 'From:'.$_SESSION['buzz_user_username'].' <'.$_SESSION['email-add'] .'>' . "\r\n";
				$headers .= "Reply-To: " . $_SESSION["email-add"] . "\r\n";
			/*$headers =  $_SESSION['email-add'] . "\r\n" .
			'Reply-To: '.$_SESSION['email-add'].'' . "\r\n" .
			'X-Mailer: PHP/' . phpversion();*/
			$date = date('Y/m/d H:i:s');
			mail($to, $subject, $message1, $headers);			
		}
		$date = date('Y/m/d H:i:s');
		$data = array(
	               'des'=>$message,
	               'group_id' => $group_id,
	               'user_id' => $_SESSION['buzz_user_id'],
	               'subject' => $subject,
	               'user_name'=>$_SESSION['buzz_user_email'],
					'date'=>$date
					);
		     $this->db->insert('group_email', $data);
		     $_SESSION['success_group_email'] = 'successfully sent email to group member ';
		redirect('welcome/manage_group');
	}
	public function register_page()
	{
		//session_start();
		$this->load->view('register_page');
	}	
	public function setting()
	{
		//session_start();
		$user_id = $_SESSION['buzz_user_id'];
		$data['user_detail'] =  $this->db->get_where('user', array('id' => $user_id))->row();
		$this->load->view('setting',$data);
	}
	public function logout()
	{
		//session_start();
		session_unset();
   		session_destroy();
		redirect('welcome/welcome_message');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
