<!--<head>
<title>
Email buzz
</title>
</head>
<center>
<h1>Email buzz</h1>
<h4>Please Login first</h4>
<?php echo form_open('welcome/login_check'); ?>
<?php if(isset($error)){ echo 'Invalid username or password'; } ?><br>
user email: <input id="email" name="email" type="email" /><br>
password: <input id="password" name="password" type="password" /><br>
<input type="submit"/>
</form>
<div>
</div>
</center>-->
<?php //session_unset(); ?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Group Email System</title>
	<link rel="stylesheet" href="<?php echo base_url(); ?>/css/style.css" />
</head>
<body>
	<?php //include 'email_buzz.php';
  ?>
  <div class="login-box">
    <div class="lb-header">
    <h1>Group Email System</h1>
      <a href="#" class="active" id="login-box-link">Login</a>
      <a href="#" id="signup-box-link">Sign Up</a>
    </div><br>
    <!--<div class="social-login">
      <a href="#">
        <i class="fa fa-facebook fa-lg"></i>
        Login in with facebook
      </a>
      <a href="#">
        <i class="fa fa-google-plus fa-lg"></i>
        log in with Google
      </a>
    </div>-->
    <?php 
	$attributes = array('class' => 'email-login', 'id' => 'myform');
    echo form_open('welcome/login_check',$attributes); ?>
      <div class="u-form-group">
        <input type="email" id="email" name="email" placeholder="Email" required/>
      </div>
      <div class="u-form-group">
        <input type="password" id="password" name="password" placeholder="Password" required/>
      </div>
      <div class="u-form-group">
        <button>Log in</button>
      </div>
      <div class="u-form-group">
        <!--<a href="#" class="forgot-password">Forgot password?</a>-->
        <?php 
        //session_start();
        if(isset($_SESSION['error-login'])){ echo 'Invalid username or password';
        session_unset($_SESSION['error-login']);
         } 
         if(isset($_SESSION['successfully_registar'])){ echo $_SESSION['successfully_registar'];
        session_unset($_SESSION['successfully_registar']);
         }
         ?>
      </div>
    </form>
    <?php 
  $attributes = array('class' => 'email-signup', 'id' => 'myform');
    echo form_open('welcome/register',$attributes); ?>
      <div class="u-form-group">
        <input type="email" name="email" placeholder="Email" required/>
      </div>
      <div class="u-form-group">
        <input type="text" name="user_name" placeholder="Full name" required/>
      </div>
      <div class="u-form-group">
        <input type="password" name="password" id="password1" placeholder="Password" required/>
      </div>
      <div class="u-form-group">
        <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" required/>
      </div>
      <div class="u-form-group">
      <input type="submit" value="Submit">
      <script type="text/javascript">
        function myFunction() {
          var pass1 = document.getElementById("password1").value;
          var pass2 = document.getElementById("confirm_password").value;
          var ok = true;
          if (pass2 != pass1) {
              //alert("Passwords Do not match");
              document.getElementById("password1").style.borderColor = "#E34234";
              document.getElementById("confirm_password").style.borderColor = "#E34234";
              ok = false;
          }
          else {
              //alert("Passwords Match!!!");
          }
          return ok;
      }
      </script>
      </div>
    </form>
  </div>
	
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript"> 
$(".email-signup").hide();
$("#signup-box-link").click(function(){
  $(".email-login").fadeOut(100);
  $(".email-signup").delay(100).fadeIn(100);
  $("#login-box-link").removeClass("active");
  $("#signup-box-link").addClass("active");
});
$("#login-box-link").click(function(){
  $(".email-login").delay(100).fadeIn(100);;
  $(".email-signup").fadeOut(100);
  $("#login-box-link").addClass("active");
  $("#signup-box-link").removeClass("active");
});
</script>
</body>
</html>