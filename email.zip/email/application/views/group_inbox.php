<?php 
include 'header.php';
include 'email_buzz.php';
?>
<div class="col-md-12">
			<div class="row">
				<div class="col-md-3">
					<?php include 'nav_bar.php'; ?>
				</div>
				<div class="col-md-8">
				<table class="table table-hover">
				<thead>
					<tr>
						<th>
							NO
						</th>
						<th>
							To
						</th>
						<th>
							Subject
						</th>
						<th>
							Message
						</th>
						<th>
							Date
						</th>
						<th>
							Action
						</th>
					</tr>
				</thead>
				<tbody>
				<?php 
				if($email_inbox == null || $email_inbox == ''){ echo "<h4>No email</h4>"; }
				else{
					$a=1;
				foreach ($email_inbox as $value) {
				
				 ?>
					<tr>
						<td>
							<?php echo $a; $a++; ?> 
						</td>
						<td>
							<?php echo $value->to_email; ?>
						</td>
						<td>
							<?php echo $value->subject; ?>
						</td>
						<td>
							<?php echo $value->des; ?>
						</td>
						<td>
							<?php echo $value->date; ?>
						</td>
						<td>
						<?php echo anchor('welcome/delete_email/'.$value->email_id, '<i class="fa fa-trash"></i>', 'class="btn btn-danger btn-xs" onclick="return confirm("Are you sure to Delete?")"');
						?>
						</td>
					</tr>
					<?php } } ?>
				</tbody>
				<script type="text/javascript">
				function check()
				{
					confirm("Do you want to delete_email!!");
				}
				</script>
			</table>
				</div>
			</div>
</div>
