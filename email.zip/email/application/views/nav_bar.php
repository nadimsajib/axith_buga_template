<ul class="nav nav-pills nav-stacked">
    <li class="nav-divider"></li>
    <li role="presentation" <?php if($this->uri->uri_string() == '' || $this->uri->uri_string() == 'welcome/home' ){ echo 'class="active"'; } ?> ><?php echo anchor('welcome/home', 'Compose'); ?></li>
    <li class="nav-divider"></li>
    <li role="presentation" onclick="toggle_visibility('pv2')" data-parent="#p2">
        <a class="nav-sub-container">Inbox <span class="caret arrow"></span></a>
        <ul class="nav nav-pills nav-stacked collapse out" id="pv2" style="display:none;height: auto;">
            <li <?php if($this->uri->uri_string() == 'welcome/inbox'){ echo 'class="active"'; } else { echo 'class=""'; } ?> ><?php echo anchor('welcome/inbox', 'Single Inbox'); ?></li>
            <li <?php if($this->uri->uri_string() == 'welcome/group_email_inbox'){ echo 'class="active"'; } else { echo 'class=""'; } ?> ><?php echo anchor('welcome/group_email_inbox', 'Group Inbox'); ?></li>
        </ul>
    </li>
    <li class="nav-divider"></li>
    <li role="presentation" <?php if($this->uri->uri_string() == 'welcome/sent'){ echo 'class="active"'; } ?> ><?php echo anchor('welcome/sent', 'Sent Email'); ?></li>
    <li class="nav-divider"></li>
    <!--<li role="presentation" <?php /*if($this->uri->uri_string() == 'welcome/manage_group' || $this->uri->segment(2) == 'group_email' || $this->uri->segment(2) == 'group_email_edit' || $this->uri->segment(2) == 'manage_group_create' || $this->uri->segment(2) == 'manage_group_manage' || $this->uri->segment(2) == 'group_email_inbox_you' || $this->uri->segment(2) == 'group_email_inbox'){ echo 'class="dropdown active"'; } else { echo 'class="dropdown"'; } */?> ><?php /*echo anchor('welcome/manage_group_create', 'Group',array('class' => 'dropdown-toggle','data-toggle' => 'dropdown')); */?>
        <ul class="dropdown-menu" role="menu">
            <li><?php /*echo anchor('welcome/manage_group_create', 'Create Group'); */?></li>
            <li><?php /*echo anchor('welcome/manage_group_manage', 'Manage groups'); */?></li>
            <li><?php /*echo anchor('welcome/manage_group', 'Sent group email'); */?></li>
            <li><?php /*echo anchor('welcome/group_email_inbox_you', 'Group Outbox'); */?></li>
            <li><?php /*echo anchor('welcome/group_email_inbox', 'Group Inbox'); */?></li>
        </ul>
    </li>-->
    <li onclick="toggle_visibility('pv1')" data-parent="#p1">
        <a class="nav-sub-container">Group Setting<span class="caret arrow"></span></a>
        <ul class="nav nav-pills nav-stacked collapse out" id="pv1" style="display:none;height: auto;">
            <li <?php if($this->uri->uri_string() == 'welcome/manage_group_create'){ echo 'class="active"'; } else { echo 'class=""'; } ?> ><?php echo anchor('welcome/manage_group_create', 'Create Group'); ?></li>
            <li <?php if($this->uri->uri_string() == 'welcome/manage_group_manage' || $this->uri->segment(2) == 'group_email_edit' || $this->uri->segment(2) == 'group_email' || $this->uri->segment(2) == 'manage_group'){ echo 'class="active"'; } else { echo 'class=""'; } ?> ><?php echo anchor('welcome/manage_group_manage', 'Manage groups'); ?></li>
            <!--<li <?php /*if($this->uri->uri_string() == 'welcome/manage_group'){ echo 'class="active"'; } else { echo 'class=""'; } */?> ><?php /*echo anchor('welcome/manage_group', 'Sent group email'); */?></li>-->
            <!--<li <?php /*if($this->uri->uri_string() == 'welcome/group_email_inbox_you'){ echo 'class="active"'; } else { echo 'class=""'; } */?> ><?php /*echo anchor('welcome/group_email_inbox_you', 'Group Outbox'); */?></li>
            <li <?php if($this->uri->uri_string() == 'welcome/group_email_inbox'){ echo 'class="active"'; } else { echo 'class=""'; } ?> ><?php echo anchor('welcome/group_email_inbox', 'Group Inbox'); ?></li>-->
        </ul>
    </li>
    <li class="nav-divider"></li>
    <!--<li role="presentation" <?php if($this->uri->uri_string() == 'welcome/group_email_inbox'){ echo 'class="active"'; } ?> ><?php echo anchor('welcome/group_email_inbox', 'Group Sent email'); ?></li>
					<li role="presentation" <?php if($this->uri->uri_string() == 'welcome/group_email_inbox_you'){ echo 'class="active"'; } ?> ><?php echo anchor('welcome/group_email_inbox_you', 'Group inbox'); ?></li>-->
    <li role="presentation" <?php if($this->uri->uri_string() == 'welcome/setting'){ echo 'class="active"'; } ?> ><?php echo anchor('welcome/setting', 'Account Setting'); ?></li>
    <li class="nav-divider"></li>
    <li role="presentation"><?php echo anchor('welcome/logout', 'Logout'); ?></li>
    <li class="nav-divider"></li>
</ul>