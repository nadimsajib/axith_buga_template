<?php include 'header.php'; ?>
<?php include 'email_buzz.php'; ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-3">
				<?php include 'nav_bar.php'; ?>
				</div>
				<div class="col-md-6">
					<?php 
					if(isset($_SESSION['manage_group_create'])){
						unset($_SESSION['manage_group_create']);
						//session_write_close();
					$add = array('class'=>'form-horizontal');
					echo form_open('welcome/add_group',$add);
					if(isset($_SESSION['successfully_insert_gropup_member'])){ echo $_SESSION['successfully_insert_gropup_member'];
					unset($_SESSION['successfully_insert_gropup_member']);
				    session_write_close();
					 }
					 if(isset($_SESSION['success_group_email'])){ echo $_SESSION['success_group_email'];
					unset($_SESSION['success_group_email']);
					unset($_SESSION['manage_group_create']);
				    // Explicitly write and close the session for good measure
				    session_write_close();
					 }
					 ?>
					<!--<div class="form-group">
    				<div class="col-xs-4">
    				<label>Group Name : </label>
					  <input type="text" name="group_name" id="group_name" class="form-control" placeholder="Group name" required>
					  </div>
					  </div>
					  <div class="form-group">
					  <div class="col-xs-6">
					  <label>Group Members : </label><br>
					  <input type="text" id="member1" name="member1" class="form-control" required>
						</div>
					</div>
					<div class="form-group">
    				<center><button type="submit" class="btn btn-success">Add group</button></center>
    				</div>
    				</form>-->
						<div class="panel panel-success">
							<!-- Default panel contents -->
							<div class="panel-heading"><h4>Create Group</h4></div>
							<div class="panel-body">
								<div class="col-md-10">
										<div class="form-group">
											<label for="group_name">Group Name :</label>
											<input type="text" class="form-control" name="group_name" id="group_name" required>
										</div>
										<div class="form-group">
											<label for="group_member">Group Member:</label>
											<select class="form-control" name="group_member[]" id="group_member" multiple required>
											</select>
										</div>
									<div class="form-group">
									<button type="submit" class="btn btn-success">Create group</button>
									</div>
									</form>
								</div>
							</div>
							</div>
    				<?php }else{ ?>
    				<div class="panel panel-success">
					  <!-- Default panel contents -->
					  <div class="panel-heading"><h4 class="pull-left">Your group list</h4><?php echo anchor('welcome/manage_group_create', 'Create Group<i class="fa fa-plus"></i>','class="btn btn-success pull-right"'); ?>
						  <div class="clearfix"></div></div>
					  <table class="table table-striped">
					    <thead>
							<tr>
								<td>
									No
								</td>
								<td>
									Group Name
								</td>
								<td>
									&nbsp;&nbsp;&nbsp;&nbsp;Action
								</td>
							</tr>
						</thead>
					  <tbody>
				<?php 
				if($group_information == null || $group_information == ''){ echo "<h4>No Groups</h4>"; }
				else{
					$a=1;
				foreach ($group_information as $key=>$value)  {
				
				 ?>
					<tr>
						<td>
							<?php echo $a; $a++; ?> 
						</td>
						<td>
							<?php echo $value->group_name; ?>
						</td>
						<td>
						<?php
						if($this->uri->segment(2) == 'manage_group'){
						echo anchor('welcome/group_email/'.$value->group_id, '<i class="fa fa-paper-plane-o"></i>', 'class="btn btn-success"');
						}
						else{
							echo anchor('welcome/group_email_edit/'.$value->group_id, '<i class="fa fa-paper-plane-o"></i>', 'title="Send Group Email" class="btn btn-success"');
						}
						 ?>
						<!-- }-->
						<?php echo anchor('welcome/delete_group/'.$value->group_id, '<i class="fa fa-trash"></i>', 'title="Delete Group" class="btn btn-danger" onclick="return confirm("Are you sure to Delete?")"'); ?>
						</td>
					</tr>
					<?php } } ?>
				</tbody>
				</table>
				<script type="text/javascript">
				function check()
				{
				    confirm("Do you want to delete_group!!");
				}
				</script>
					</div>
					<div class="panel panel-success">
					  <!-- Default panel contents -->
					  <div class="panel-heading"><h4>Group where you listed</h4></div>
					  <table class="table table-striped">
						<thead>
						<tr>
							<td>No</td>
							<td>Group Name</td>
							<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Action</td>
						</tr>							
						</thead>
					  <?php 
				//var_dump($group_name_in_user);
					  if($group_name_in_user == null || $group_name_in_user == ''){ echo "<h4>No Groups</h4>"; }
					  else { $a=1;
				foreach ($group_name_in_user as $value) {
					# code...
					foreach ($value as $key) {
						//echo $key->group_name;
						?>
						
						<tbody>
						<tr>
							<td><?php echo $a; $a++; ?></td>
							<td><?php echo $key->group_name; ?></td>
							<td>
								<?php echo anchor('welcome/group_email/'.$key->group_id, '<i class="fa fa-paper-plane-o"></i>', 'class="btn btn-success"','title="Send Group Email"'); ?>
							</td>
						</tr>							
						</tbody>
						<?php
					}
				}}
				 ?></table></div></div>
				</div>
				<?php } ?>
				<div class="col-md-3">		
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
function addFields(){
            var number = document.getElementById("member").value;
            var container = document.getElementById("container1");
            //while (container.hasChildNodes()) {
                //container.removeChild(container.lastChild);
            //}
            for (i=0;i<number;i++){
                container.appendChild(document.createTextNode("Member " + (i+1)));
                var input = document.createElement("input");
                input.type = "email";
                input.name = "member_name[]";
                container.appendChild(input);
                container.appendChild(document.createElement("br"));
            }
        }
$("#group_member").select2({
	tags: true,
	tokenSeparators: [',', ' ']
})
/*
$("#group_member").tagsinput({
	onTagExists: function(item, $tag) {
		$tag.hide.fadeIn();
	}
});*/
</script>
<?php include 'footer.php'; ?>