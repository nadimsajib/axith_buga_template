<!DOCTYPE html>
<html lang="en">
<?php include 'header.php'; ?>
		<?php 
		include 'email_buzz.php'; ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-3">
					<?php include 'nav_bar.php'; ?>
				</div>
				<div class="col-md-6">
				
				<div class=""> 
				<?php if(isset($_SESSION['success_single_email'])){ echo '<p class="text-success">'.$_SESSION['success_single_email'].'</p>'; }
					unset($_SESSION['success_single_email']);
				    session_write_close(); ?>
					<h4>Write Message</h4>
				</div>
				<div class=""> 
					<?php echo form_open('welcome/sent_single_email'); ?>
					<!--<div class="form-group">
                        <label for="exampleInputEmail1">To</label>
                        <br>
                        <input type="radio" value="group" name="chose" id="chose1" required><label for="chose1"> Group </label><br>
                        <input type="radio" value="single" name="chose" id="chose2" required><label for="chose2"> Single </label>
                    </div>-->
					<div class="form-group" id="group">
						<label for="group_selection">Create Group</label>
						<?php echo anchor('welcome/manage_group_create', '<i class="fa fa-plus"></i>', 'class="btn btn-success btn-xs"'); ?><br>OR<br>
						<label for="group_selection">Group Name</label><br>
						<select class="form-control" id="group_selection" name="group_email[]" multiple>
							<?php
							foreach($group as $row)
							{
								echo '<option value="'.$row['group_id'].'">'.$row['group_name'].'</option>';
							}
							?>
						</select>
						<!--<input type="email" class="form-control" id="query" name="to_email" placeholder="group name" data-provide="typeahead" required>-->
					</div>
					<div class="form-group" id="single" >
						<label for="single_selection">Email Address</label><br>
						<select class="form-control" id="single_selection" name="to_email[]" multiple>
						</select>
						<!--<input type="email" class="form-control" id="single_selection" name="to_email" placeholder="email address" data-provide="typeahead" required>-->
					</div>
						<div class="form-group"> 
							<label for="exampleInputEmail1">Subject</label>
							<input type="text" class="form-control" id="exampleInputEmail1" name="to_subject" placeholder="Subject" required>
						</div>
						<div class="form-group">
						<label for="compose">Compose:</label>
						<textarea class="form-control" name="email_des" rows="5" required></textarea>
						</div>
					<div class="form-group">
						<label for="">Attachment File</label>
						<input type="file" id="">
				 </div>				
				<input type="submit" class="btn btn-success" value="Submit">
				<button type="reset" class="btn btn-danger">Reset</button>
					</form>
				</div>
			</div>
				<div class="col-md-3">
				</div>
			</div>
		</div>
	</div>
</div>
<style type="text/css">
	.twitter-typeahead{
width:100%;
}

.twitter-typeahead .tt-query,
.twitter-typeahead .tt-hint {
  margin-bottom: 0;
}
.tt-dropdown-menu {
  min-width: 160px;
  margin-top: 2px;
  padding: 5px 0;
  background-color: #fff;
  border: 1px solid #ccc;
  border: 1px solid rgba(0,0,0,.2);
  *border-right-width: 2px;
  *border-bottom-width: 2px;
  -webkit-border-radius: 6px;
     -moz-border-radius: 6px;
          border-radius: 6px;
  -webkit-box-shadow: 0 5px 10px rgba(0,0,0,.2);
     -moz-box-shadow: 0 5px 10px rgba(0,0,0,.2);
          box-shadow: 0 5px 10px rgba(0,0,0,.2);
  -webkit-background-clip: padding-box;
     -moz-background-clip: padding;
          background-clip: padding-box;
  width:100%;        
}

.tt-suggestion {
  display: block;
  padding: 3px 20px;
}

.tt-suggestion.tt-is-under-cursor {
  color: #fff;
  background-color: #0081c2;
  background-image: -moz-linear-gradient(top, #0088cc, #0077b3);
  background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#0088cc), to(#0077b3));
  background-image: -webkit-linear-gradient(top, #0088cc, #0077b3);
  background-image: -o-linear-gradient(top, #0088cc, #0077b3);
  background-image: linear-gradient(to bottom, #0088cc, #0077b3);
  background-repeat: repeat-x;
  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0088cc', endColorstr='#ff0077b3', GradientType=0)
}

.tt-suggestion.tt-is-under-cursor a {
  color: #fff;
}

.tt-suggestion p {
  margin: 0;
}
</style>
<script type="text/javascript">
	/*$( document ).ready(function() {
		$('#group').hide();
		$('#single').hide();
		$('input[type="radio"]').click(function() {
			if($(this).attr('id') == 'chose1') {
				$('#group').show();
				$('#single').hide();
			}
			else {
				$('#single').show();
				$('#group').hide();
			}
		});
	});
*/

	$("#group_selection").select2({
		theme: "classic"
	});

	$("#single_selection").select2({
		tags: true,
		tokenSeparators: [',', ' ']
	})
</script>
<?php include 'footer.php'; ?>