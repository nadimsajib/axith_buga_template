<?php 
include 'header.php';
include 'email_buzz.php';
?>
<div class="col-md-12">
			<div class="row">
				<div class="col-md-3">
					<?php include 'nav_bar.php'; ?>
				</div>
				<div class="col-md-6">
				<h3>Setting</h3>
				 <?php echo form_open('welcome/setting'); ?>
						<div class="form-group"> 
							<label for="exampleInputEmail1">Old password</label>
							<input type="text" class="form-control" id="exampleInputEmail1" name="password" placeholder="Old password" required>
						</div>
						<div class="form-group">
						<label for="compose">new password</label>
						<input type="text" class="form-control" id="exampleInputEmail1" name="password" placeholder="new password" required>
						</div>		
						<div class="form-group">
						<label for="compose">retype new password</label>
						<input type="text" class="form-control" id="exampleInputEmail1" name="" placeholder="retype new password" required>
						</div>
					<div class="form-group">
						<label for="compose">Smtp</label>
						<input type="text" class="form-control" value="<?php echo $user_detail->smtp ?>" name="to_subject" required>
					</div>
					<div class="form-group">
						<label for="compose">Smtp Port</label>
						<input type="number" class="form-control" value="<?php echo $user_detail->smtp_port ?>"name="smtp_port" required>
					</div>
					<div class="form-group">
						<label for="compose">Imap</label>
						<input type="text" class="form-control" value="<?php echo $user_detail->imap ?>" name="imap" required>
					</div>
					<div class="form-group">
						<label for="compose">Imap port</label>
						<input type="text" class="form-control" value="<?php echo $user_detail->imap_port ?>" name="imap_port" required>
					</div>
				<input type="submit" class="btn btn-success" value="Submit">
				<button type="reset" class="btn btn-danger">Reset</button>
					</form>
				</div>