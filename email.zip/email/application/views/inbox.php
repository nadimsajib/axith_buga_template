<?php 
include 'header.php';
include 'email_buzz.php';
?>
<div class="col-md-12">
			<div class="row">
				<div class="col-md-3">
					<?php include 'nav_bar.php'; ?>
				</div>
				<div class="col-md-8">
				<?php if(isset($email_inbox)) { ?>
				<h3>Email list</h3>
				<table class="table table-hover">
				<thead>
					<tr>
						<th>
							NO
						</th>
						<th>
							To
						</th>
						<th>
							Subject
						</th>
						<th>
							Message
						</th>
						<th>
							Date
						</th>
						<th>
							Action
						</th>
					</tr>
				</thead>
				<tbody>
				<?php
				if($email_inbox == null || $email_inbox == ''){ echo "<h4>No email</h4>"; }
				else{
					$a=1;
				foreach ($email_inbox as $value) {

				 ?>
					<tr>
						<td>
							<?php echo $a; $a++; ?>
						</td>
						<td>
							<?php echo $value->to_email; ?>
						</td>
						<td>
							<?php echo $value->subject; ?>
						</td>
						<td>
							<?php echo $value->des; ?>
						</td>
						<td>
							<?php echo $value->date; ?>
						</td>
						<td>
						<?php echo anchor('welcome/delete_email/'.$value->email_id, '<i class="fa fa-trash"></i>', 'title="Delete Email" class="btn btn-danger" onclick="return confirm("Are you sure to Delete?")"');
						?>
						</td>
					</tr>
					<?php } } ?>
				</tbody>
				<script type="text/javascript">
				function check()
				{
					confirm("Do you want to delete_email!!");
				}
				</script>
			</table>
			<?php }
			if(isset($group_email_gain)) { ?>
			<h3>Group Outbox list</h3>
				<table class="table table-hover">
				<thead>
					<tr>
						<th>
							NO
						</th>
						<th>
							Group
						</th>
						<th>
							Subject
						</th>
						<th>
							Message
						</th>
						<th>
							User email
						</th>
						<th>
							Date
						</th>
						<th>
							Action
						</th>
					</tr>
				</thead>
				<tbody>
				<?php
				if($group_email_gain == null || $group_email_gain == ''){ echo "<h4>No email</h4>"; }
				else{
					$a=1;
					$b=0;
					//var_dump($group_email_gain);
				foreach ($group_email_gain as $value) {
					foreach ($value as $row) {


				 ?>
					<tr>
						<td>
							<?php echo $a;  ?>
						</td>
						<td>
							<?php
							foreach ($group_name[$b] as $value1) {
								echo $value1['group_name'];
								//echo $value1[$b]['group_name'];
							}
							//echo $group_name[$b];

							//$value->group_id; ?>
						</td>
						<td>
							<?php echo $row['subject']; ?>
						</td>
						<td>
							<?php echo $row['des']; ?>
						</td>
						<td>
							<?php echo $row['user_name']; ?>
						</td>
						<td>
							<?php echo $row['date'];$a++; ?>
						</td>
						<td>
						<?php echo anchor('welcome/delete_group_email/'.$value[$b]['group_email_id'], '<i class="fa fa-trash"></i>', 'title="Delete Email" class="btn btn-danger" onclick="return confirm("Are you sure to Delete?")"');

						 ?>
						</td>
					</tr>
					<?php }$b++;} } ?>
				</tbody>
				<script type="text/javascript">
				function check()
				{
					confirm("Do you want to delete_email!!");
				}
				</script>
			</table>
			<?php }
			if(isset($group_email_inbox)){
			 ?>
			 <h3>Group Inbox list</h3>
			 <table class="table table-hover">
				<thead>
					<tr>
						<th>
							NO
						</th>
						<th>
							Group
						</th>
						<th>
							Subject
						</th>
						<th>
							Message
						</th>
						<th>
							User email
						</th>
						<th>
							Date
						</th>
						<th>
							Action
						</th>
					</tr>
				</thead>
				<tbody>
				<?php
				if($group_email_inbox == null || $group_email_inbox == '' ){ echo "<h4>No email</h4>"; }
				else{
					$a=1;
					$b=0;
				foreach ($group_email_inbox as $value) {

				 ?>
					<tr>
						<td>
							<?php echo $a;  ?>
						</td>
						<td>
							<?php
							echo $group_name[$b];
							$b++;
							//$value->group_id; ?>
						</td>
						<td>
							<?php echo $value->subject; ?>
						</td>
						<td>
							<?php echo $value->des; ?>
						</td>
						<td>
							<?php echo $value->user_name; ?>
						</td>
						<td>
							<?php echo $value->date; $a++; ?>
						</td>
						<td>
						<?php echo anchor('welcome/delete_group_email/'.$value->group_email_id, '<i class="fa fa-trash"></i>', 'title="Delete Email" class="btn btn-danger" onclick="return confirm("Are you sure to Delete?")"');
						?>
						</td>
					</tr>
					<?php } } ?>
				</tbody>
				<script type="text/javascript">
				function check1()
				{
				    confirm("Do you want to delete_email!!");
				}
				</script>
			</table>
			<?php } ?>
				</div>
			</div>
	</div>