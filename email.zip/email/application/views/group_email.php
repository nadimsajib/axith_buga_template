<?php 
include 'header.php';
include 'email_buzz.php';
?>
<div class="col-md-12">
			<div class="row">
				<div class="col-md-3">
					<?php include 'nav_bar.php'; ?>
				</div>
				<div class="col-md-8">
				<h3>Group Email</h3>
				<div class="panel panel-success">
					  <!-- Default panel contents -->
					  <div class="panel-heading">Your group member</div>
					<?php $group_id_for_add = $group_id; ?>
				<?php foreach ($group_member as $value) {
					echo '<div class="panel-body">'.$value->member_name.'&nbsp;';
					/*$group_id_for_add = $value->group_id;*/
					echo anchor('welcome/delete_group_member/'.$value->member_id.'/'.$value->group_id, '<i class="fa fa-trash"></i>', 'title="Delete Member" class="btn btn-danger btn-xs" onclick="return confirm("Are you sure to Delete?")"');
					echo "</div>";
				} 
				$add = array('class'=>'form-horizontal');
					echo form_open('welcome/add_group_member',$add);
				?>
				<div class="col-xs-8">
				<input type="email" name="member_name" id="member_name" class="form-control" placeholder="member name" required>
				<input type="hidden" name="group_id" id="group_id" value="<?php echo $group_id_for_add; ?>" >
				</div>
				<button type="submit" class="btn btn-success">Add member</button>
				</form>
				</div>
				<script type="text/javascript">
				function check()
				{
					confirm("Do you want to delete member!!");
				}
				</script>
				<?php
				 echo form_open('welcome/sent_group_email'); ?>
						<div class="form-group"> 
							<label for="exampleInputEmail1">Subject</label>
							<input type="text" class="form-control" id="exampleInputEmail1" name="to_subject" placeholder="Subject" required>
						</div>
						<div class="form-group">
						<label for="compose">Compose:</label>
						<textarea class="form-control" name="email_des" rows="5" required></textarea>
						</div>
					<div class="form-group">
						<label for="">Attachment File</label>
						<input type="file" id="">
				 </div>				
				<input type="submit" class="btn btn-success" value="Submit">
				<button type="reset" class="btn btn-danger">Reset</button>
				<input type="hidden" name="group_id" value="<?php echo $group_id; ?>">
					</form>
				</div>