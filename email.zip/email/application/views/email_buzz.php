<div class="container"> 
			<div class="row"> 
			<div class="col-md-12">
				<div class="top-header">
					<h1 class="text-center">Group Email System</h1>
					<h5 class="text-center"><?php
						echo 'Welcome <b>'.$_SESSION['buzz_user_username'].'('.$_SESSION['buzz_user_email'].')</b>';  ?></h5>
				</div>
			</div>
			</div>
		</div>
<hr>