<?php
class Email_model extends CI_Model {
	  function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	function explicit($query) 
	{ 
		$q = $this->db->query($query); 
			if(is_object($q)) 
			{ 
				return $q->result_array(); 
			} 
			else 
			{ 
				return $q; 
			}
	}
	function get_user($email, $password)
    {
		//$username = $username;
		
        $query = $this->db->get_where('user', array('email' => $email, 'password' => $password));
		//var_dump($query);
        return $query->result();
    }
	function get_entries($email, $password)
    {
		//$username = $username;
        $query = $this->db->get_where('user', array('email' => $email, 'password' => $password));
		//var_dump($query);
        return $query->result();
    }
     function get_entries_email($email)
    {
		//$username = $username;
        $query = $this->db->get_where('user', array('email' => $email));
		//var_dump($query);
        return $query->result();
    }
    function get_entries_reg($email)
    {
		//$username = $username;
        $query = $this->db->get_where('user', array('email' => $email));
		//var_dump($query);
        return $query->result();
    }
}
?>