-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2015 at 02:29 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `email`
--

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE IF NOT EXISTS `email` (
`email_id` int(255) NOT NULL,
  `to_email` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `des` text NOT NULL,
  `user_id` int(255) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`email_id`, `to_email`, `subject`, `des`, `user_id`, `user_name`, `date`) VALUES
(6, 'nadimuldecj@gmail.com', 'nadim', ' asda sdas dasd asd ', 1, '', '2015/07/28 19:11:36'),
(8, 'nadimuldecj@gmail.com', 'test 2 ', 'hay nadimuldecj@yahoo.com', 1, '', '2015/07/29 19:35:51'),
(9, 'nadimuldecj@gmail.com', 'asdasd', 'asdasdasdas', 3, 'nadimul.agv@gmail.com', '2015/08/01 16:30:21');

-- --------------------------------------------------------

--
-- Table structure for table `group_detail`
--

CREATE TABLE IF NOT EXISTS `group_detail` (
`group_id` int(255) NOT NULL,
  `group_name` varchar(255) NOT NULL,
  `user_id` int(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `group_detail`
--

INSERT INTO `group_detail` (`group_id`, `group_name`, `user_id`) VALUES
(22, 'new', 3),
(24, 'new ', 2);

-- --------------------------------------------------------

--
-- Table structure for table `group_email`
--

CREATE TABLE IF NOT EXISTS `group_email` (
`group_email_id` int(255) NOT NULL,
  `group_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `des` text NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `group_email`
--

INSERT INTO `group_email` (`group_email_id`, `group_id`, `user_id`, `subject`, `des`, `user_name`, `date`) VALUES
(12, 24, 2, 'asdasd', 'asdasdasdasdas', 'nadimuldecj@yahoo.com', '2015/07/29 20:16:10'),
(13, 24, 1, 'ttrt', 'uuj8hggvvg', 'nhsajib316@gmail.com', '2015/07/30 10:55:40'),
(14, 24, 2, 'nadim', 'hghffdfdfdfdsf', 'nadimuldecj@yahoo.com', '2015/07/30 14:05:40'),
(15, 24, 2, 'the dus', 'so this is dos attack ', 'nadimuldecj@yahoo.com', '2015/07/30 20:43:26'),
(16, 24, 1, 'new 223', 'this is sint by nhsajib316@gmail.com', 'nhsajib316@gmail.com', '2015/08/01 09:59:23'),
(17, 24, 2, 'subject', 'asdasdas df', 'nadimuldecj@yahoo.com', '2015/08/01 13:07:09'),
(18, 24, 1, 'this is nhsajib316', 'sdfsdf', 'nhsajib316@gmail.com', '2015/08/01 16:05:04'),
(19, 22, 3, 'dads', 'ccccccc', 'nadimul.agv@gmail.com', '2015/08/01 18:20:04');

-- --------------------------------------------------------

--
-- Table structure for table `group_member`
--

CREATE TABLE IF NOT EXISTS `group_member` (
`member_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `group_id` int(255) NOT NULL,
  `member_name` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `group_member`
--

INSERT INTO `group_member` (`member_id`, `user_id`, `group_id`, `member_name`) VALUES
(27, 2, 24, 'nhsajib316@gmail.com'),
(28, 2, 24, 'nadimul.agv@gmail.com'),
(29, 3, 0, 'nhsajib316@gmail.com'),
(30, 3, 0, 'mohaiman.agv@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(255) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_name`, `email`, `password`) VALUES
(1, 'nadimul haque', 'nhsajib316@gmail.com', '12345'),
(2, 'cj', 'nadimuldecj@yahoo.com', '12345'),
(3, 'nadim', 'nadimul.agv@gmail.com', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `email`
--
ALTER TABLE `email`
 ADD PRIMARY KEY (`email_id`);

--
-- Indexes for table `group_detail`
--
ALTER TABLE `group_detail`
 ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `group_email`
--
ALTER TABLE `group_email`
 ADD PRIMARY KEY (`group_email_id`);

--
-- Indexes for table `group_member`
--
ALTER TABLE `group_member`
 ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `email`
--
ALTER TABLE `email`
MODIFY `email_id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `group_detail`
--
ALTER TABLE `group_detail`
MODIFY `group_id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `group_email`
--
ALTER TABLE `group_email`
MODIFY `group_email_id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `group_member`
--
ALTER TABLE `group_member`
MODIFY `member_id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
